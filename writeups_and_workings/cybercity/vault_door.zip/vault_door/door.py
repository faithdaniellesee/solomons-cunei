from config import *

key_file = "hex-CTF.key"
"""
====================================
With my brilliance, they'll never be able to guess our password!

This solution should keep our secrets out of our competitors! Especially that damned Linguine!

They'll never figure out that they need to put the code back into REMI's interface
to unlock the door that leads to Remi.

            -- Head Chef Skinner
====================================
"""


def compress(expanded):
    a = ''
    for i in expanded:
        a += str(hex(i)).strip('0x').rjust(2, '0')
    return a


def expand(raw):
    tab = []
    for i in range(len(raw)//2):
        h = int(raw[i:i+2], 16)
        tab.append(h)
    return tab


def retrieve_key_data(key_file):
    with open(key_file) as f:
        raw = f.read().rstrip("\n")
        print(raw)
    return raw


def obfusticate(raw):
    mappings = {0: 0, 3: 2, 1: 4, 4: 1, 2: 3, 5: 5, 8: 7, 6: 9, 9: 6, 7: 8, 10: 10, 13: 12, 11: 14, 14: 11, 12: 13, 15: 15, 18: 17, 16: 19, 19: 16, 17: 18, 20: 20,
                23: 22, 21: 24, 24: 21, 22: 23, 25: 25, 28: 27, 26: 29, 29: 26, 27: 28, 30: 30, 33: 32, 31: 34, 34: 31, 32: 33, 35: 35, 38: 37, 36: 39, 39: 36, 37: 38}
    obfs = swap_letters(mappings, raw)
    return obfs


def main():
    doorcode = retrieve_key_data(key_file)
    password = input("Enter Door Code:")
    f = expand(doorcode)
    for i in range(len(f)):
        f[i] = (len(f)-i) ^ f[i]
    doorcode = compress(obfusticate(f))
    print(doorcode)

    if(password == doorcode):
        print("Access Granted.")
    else:
        print("Access Denied!!")
    dumpfile(doorcode)


main()
